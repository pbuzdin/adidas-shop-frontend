import React from 'react';
import ReactDOM from 'react-dom';
// import App from './App';
import './index.css';
import ShoesCategory from './ShoesCategory/ShoesCategory';

ReactDOM.render( <
  ShoesCategory / > ,
  document.getElementById('root')
);